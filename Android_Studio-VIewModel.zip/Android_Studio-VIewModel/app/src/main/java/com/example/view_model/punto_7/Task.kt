package com.example.view_model.punto_7

data class Task(
    val id: Int,
    val title: String,
    var isDone: Boolean = false
)
