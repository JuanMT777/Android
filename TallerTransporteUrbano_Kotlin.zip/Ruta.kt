data class Parada(val nombre: String)

class Ruta(val nombre: String, val paradas: List<Parada>, val vehiculo: Vehiculo) {
    fun recorrerRuta() {
        println("Iniciando ruta $nombre con el vehículo ${vehiculo.id}")
        for (parada in paradas) {
            println("Parada: ${parada.nombre}")
            vehiculo.moverse()
            vehiculo.detenerse()
        }
    }
}