enum class TipoCombustible {
    GASOLINA, ELECTRICO, HIBRIDO
}