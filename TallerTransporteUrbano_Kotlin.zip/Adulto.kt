class Adulto(val nombre: String) : Pasajero {
    override fun abordar(vehiculo: Vehiculo) {
        println("$nombre (Adulto) ha abordado el vehículo ${vehiculo.id}")
    }

    override fun bajar(vehiculo: Vehiculo) {
        println("$nombre (Adulto) ha bajado del vehículo ${vehiculo.id}")
    }
}