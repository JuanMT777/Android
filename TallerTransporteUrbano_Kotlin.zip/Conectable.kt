interface Conectable {
    fun conectar()
    fun desconectar()
}