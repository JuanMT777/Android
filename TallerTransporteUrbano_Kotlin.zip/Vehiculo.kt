abstract class Vehiculo(
    val id: String,
    val capacidad: Int,
    val velocidadMax: Int
) {
    abstract fun moverse()
    abstract fun detenerse()
}