class Bus(
    id: String, capacidad: Int, velocidadMax: Int,
    val tipoCombustible: TipoCombustible
) : Vehiculo(id, capacidad, velocidadMax) {
    override fun moverse() = println("El bus $id está en movimiento.")
    override fun detenerse() = println("El bus $id se ha detenido.")
}