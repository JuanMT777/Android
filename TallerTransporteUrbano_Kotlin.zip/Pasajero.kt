interface Pasajero {
    fun abordar(vehiculo: Vehiculo)
    fun bajar(vehiculo: Vehiculo)
}