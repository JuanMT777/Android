class Conductor(val nombre: String, val edad: Int) {
    val vehiculosAsignados = mutableListOf<Vehiculo>()
    fun asignarVehiculo(vehiculo: Vehiculo) {
        vehiculosAsignados.add(vehiculo)
        println("$nombre ha sido asignado al vehículo ${vehiculo.id}")
    }
}