object CentroControl {
    private val vehiculosActivos = mutableListOf<Vehiculo>()
    private var viajesRealizados = 0

    fun registrarVehiculo(vehiculo: Vehiculo) {
        vehiculosActivos.add(vehiculo)
        println("Vehículo ${vehiculo.id} registrado en el centro de control.")
    }

    fun registrarViaje() {
        viajesRealizados++
    }

    fun mostrarEstadisticas() {
        println("---- Estadísticas ----")
        println("Vehículos activos: ${vehiculosActivos.size}")
        println("Viajes realizados: $viajesRealizados")
        println("----------------------")
    }
}