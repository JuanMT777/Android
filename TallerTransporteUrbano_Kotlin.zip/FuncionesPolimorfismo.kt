fun operarVehiculos(vehiculos: List<Vehiculo>) {
    vehiculos.forEach {
        it.moverse()
        it.detenerse()
    }
}