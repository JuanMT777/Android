class Nino(val nombre: String) : Pasajero {
    override fun abordar(vehiculo: Vehiculo) {
        if (vehiculo.capacidad >= 1) {
            println("$nombre (Niño) ha abordado el vehículo ${vehiculo.id}")
        } else {
            println("$nombre no puede abordar el vehículo ${vehiculo.id}")
        }
    }

    override fun bajar(vehiculo: Vehiculo) {
        println("$nombre (Niño) ha bajado del vehículo ${vehiculo.id}")
    }
}