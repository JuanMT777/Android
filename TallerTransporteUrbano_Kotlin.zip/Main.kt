fun main() {
    val bus1 = Bus("B01", 40, 80, TipoCombustible.GASOLINA)
    val tren1 = Tren("T01", 100, 120, TipoCombustible.ELECTRICO)

    val conductor = Conductor("Carlos", 45)
    conductor.asignarVehiculo(bus1)
    conductor.asignarVehiculo(tren1)

    val adulto = Adulto("Ana")
    val nino = Nino("Luis")

    val ruta = Ruta(
        "Ruta Centro",
        listOf(Parada("Estación A"), Parada("Estación B"), Parada("Estación C")),
        tren1
    )

    CentroControl.registrarVehiculo(bus1)
    CentroControl.registrarVehiculo(tren1)

    tren1.conectar()
    adulto.abordar(tren1)
    nino.abordar(tren1)

    ruta.recorrerRuta()
    CentroControl.registrarViaje()

    adulto.bajar(tren1)
    nino.bajar(tren1)
    tren1.desconectar()

    CentroControl.mostrarEstadisticas()
}