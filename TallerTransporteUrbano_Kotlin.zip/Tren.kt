class Tren(
    id: String, capacidad: Int, velocidadMax: Int,
    val tipoCombustible: TipoCombustible
) : Vehiculo(id, capacidad, velocidadMax), Conectable {
    override fun moverse() = println("El tren $id está en movimiento.")
    override fun detenerse() = println("El tren $id se ha detenido.")
    override fun conectar() = println("Tren $id conectado a estación eléctrica.")
    override fun desconectar() = println("Tren $id desconectado de estación eléctrica.")
}